What happened to the FTC Software Development Tutorials???

In an effort to save space and reduce download time, the older (and outdated) tutorial documents (FTCTraining_Manual.pdf, FTC_FieldCoordinateSystemDefinition.pdf, FTC_NextGenGuide.pdf, and FTC_ZTE_ChannelChange.pdf) have been removed.

You can find the releveant PDF files attached to the "Releases" page of the GitHub repository:

https://github.com/ftctechnh/ftc_app/releases
